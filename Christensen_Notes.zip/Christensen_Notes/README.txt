README

Please see comments throughout code to understand what code is doing.

This program was built on Windows Eclipse and confirmed runs on Windows IntelliJ as well without errors.

Please make sure the Keywords.txt file is located in the project's root directory, as well as the Notes directory containing all note.txt files.

How to use:
The program will prompt you to enter a number [1-7].
After entering a number, the program will ask for further inputs.


The program can either shutdown after one service performed, or can continually run. To have program continually run, comment out "break;" at end of Main.


Sample inputs sequence (separated by dash):
1
!JUnit
-------------------------------
2
-------------------------------
3
@Morty
-------------------------------
4
Milk
-------------------------------
5
JUnit.txt
-------------------------------
6
^!Carburetor
