package impl;

import java.io.File;
import java.nio.file.NoSuchFileException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Main {

	public static void main(String [] args) throws Exception {
		// System.out.println("Hello World");
		String curDir = System.getProperty("user.dir");
		
		// processes keywords.txt and stores all keywords inside keywords.txt
		HashSet<String> keywords = new HashSet<String>();
		String keywordFileContent = "";
		try {
			keywordFileContent = Utils.readFile(curDir + "\\Keywords.txt");
			// System.out.println(keywordFileContent);
		} catch (NoSuchFileException e) {
			System.out.println("Error: Please make sure Keywords.txt is stored in this project's directory");
			System.exit(-1);
		}
		keywordFileContent = keywordFileContent.replaceAll("\r\n|\n|\r|\\.", ",");
		for (String keyword: keywordFileContent.split(",")) {
			keyword = keyword.trim().toLowerCase();
			if(keyword.length() != 0)
				keywords.add(keyword);
		}
		// System.out.println(keywords.toString());
		// initial data structures to store information about the notes
		// #1 - Report of all notes that contain a unique note identifier
		HashMap<String, String> id2File = new HashMap<String, String>();
		// #2 - Report of all notes with one or more mentions
		HashMap<String, HashSet<String>> file2Mention = new HashMap<String, HashSet<String>>();
		// #3 - Report of all notes that contain a specific mention
		HashMap<String, HashSet<String>> mention2File = new HashMap<String, HashSet<String>>();
		// #4 - Report of all note files that contain a specific keyword
		HashMap<String, HashSet<String>> keyword2File = new HashMap<String, HashSet<String>>();
		// #5 - Report of all keywords in a file
		HashMap<String, HashSet<String>> file2Keywords = new HashMap<String, HashSet<String>>();
		// #6 - Report of all notes that are linked to another note by ^
		HashMap<String, HashSet<String>> associateId2File = new HashMap<String, HashSet<String>>();
		// Processes each note
		File[] files = Utils.listFiles(curDir + "\\Notes");
		for(File f : files) {
			String oneFileContent = Utils.readFile(f.getAbsolutePath());
			// System.out.println(oneFileContent);
			// process 1
			Pattern p1 = Pattern.compile("![-_a-zA-z][-_a-zA-z0-9]*");
			ArrayList<String> matches;
			matches = Utils.matchPattern(p1, oneFileContent);
			if(matches.size() >= 1) {
				id2File.put(matches.get(0), f.getName());
			}
			// System.out.println(matches);
			// process 2
			// assuming userIds have similar definition as note ids
			Pattern p2 = Pattern.compile("@[-_a-zA-z][-_a-zA-z0-9]*");
			matches = Utils.matchPattern(p2, oneFileContent);
			if(matches.size() >= 1) {
				HashSet<String> mentions = new HashSet<String>(matches);
				file2Mention.put(f.getName(), mentions);
			}
			// process 3
			Pattern p3 = Pattern.compile("@[-_a-zA-z][-_a-zA-z0-9]*");
			matches = Utils.matchPattern(p3, oneFileContent);
			for(String mention : matches) {
				HashSet<String> fileNames = mention2File.get(mention);
				if(fileNames == null) {
					fileNames = new HashSet<String>();
					mention2File.put(mention, fileNames);
				}
				fileNames.add(f.getName());
			}
			// System.out.println(mention2File);
			// process 4
			for(String k : keywords) {
				// \b is word boundary in java regex
				Pattern p4 = Pattern.compile("\\b"+ k + "\\b");
				String lowerCaseContent = oneFileContent.toLowerCase();
				matches = Utils.matchPattern(p4, lowerCaseContent);
				if(matches.size() > 0) {
					HashSet<String> fileNames = keyword2File.get(k);
					if(fileNames == null) {
						fileNames = new HashSet<String>();
						keyword2File.put(k, fileNames);
					}
					fileNames.add(f.getName());
				}
			}
			// System.out.println(keyword2File);
			// process 5
			for(String k : keywords) {
				// \b is word boundary in java regex
				Pattern p5 = Pattern.compile("\\b"+ k + "\\b");
				String lowerCaseContent = oneFileContent.toLowerCase();
				matches = Utils.matchPattern(p5, lowerCaseContent);
				for(String m : matches) {
					HashSet<String> keys = file2Keywords.get(f.getName());
					if(keys == null) {
						keys = new HashSet<String>();
						file2Keywords.put(f.getName(), keys);
					}
					keys.add(m);
				}
			}
			// System.out.println(file2Keywords);
			// process 6
			Pattern p6 = Pattern.compile("(^!|!|^)[-_a-zA-z][-_a-zA-z0-9]*");
			matches = Utils.matchPattern(p6, oneFileContent);
			for(String m : matches) {
				m = m.replace("^!", "");
				m = m.replace("!", "");
				m = m.replaceAll("^", "");
				HashSet<String> fileNames = associateId2File.get(m);
				if(fileNames == null) {
					fileNames = new HashSet<String>();
					associateId2File.put(m, fileNames);
				}
				fileNames.add(f.getName());
			}
			// System.out.println(associateId2File);
		}
		
		// finished data processing, now ready for user input
		Scanner scan = new Scanner(System.in);
		try {  
			while(true) {
				System.out.println("Please enter a number [1-7]:");
				System.out.println("1. To find a note by its unique ID.\r\n" + 
						"2. To find notes that contain one or more mentions.\r\n" + 
						"3. To find notes that contain a specific mention.\r\n" + 
						"4. To find notes that contain a specific keyword.\r\n" + 
						"5. To list all keywords within a note.\r\n" + 
						"6. To find all notes linked to a certain unique ID.\r\n" +
						"7. To exit program.");
				String input = scan.nextLine();
				input = input.trim();
				int cmd = Integer.parseInt(input);
				if(cmd == 1) {
					System.out.println("Please enter the unique id in the form of !id");
					input = scan.nextLine().trim();
					String out = id2File.get(input) == null ? "No note found by that id." : id2File.get(input);
					System.out.println(input + ":" + out);
				}
				if(cmd == 2) {
					System.out.println("The following notes contain one or more mentions:");
					for(String fname : file2Mention.keySet()) {
						System.out.print(fname + " ");
					}
					System.out.println();
					System.out.println();
				}
				if(cmd == 3) {
					System.out.println("Please enter a mention in the form of @mention");
					input = scan.nextLine().trim();
					String out = mention2File.get(input) == null ? "No notes found with that mention." : mention2File.get(input).toString();
					System.out.println(input + ":" + out);
					System.out.println();
				}
				if(cmd == 4) {
					System.out.println("Please enter a keyword.");
					input = scan.nextLine().trim().toLowerCase();
					String out = keyword2File.get(input) == null ? "No notes found with that keyword." : keyword2File.get(input).toString();
					System.out.println(input + ":" + out);
					System.out.println();
				}
				if(cmd == 5) {
					System.out.println("Please enter a filename in the form of file.txt");
					input = scan.nextLine().trim();
					String out = file2Keywords.get(input) == null ? "No notes found with that filename." : file2Keywords.get(input).toString();
					System.out.println(input + ":" + out);
					System.out.println();
				}
				if(cmd == 6) {
					System.out.println("Please enter the unique id in the form of ^!id, !id or ^id to find linked notes.");
					input = scan.nextLine().trim().replace("^!", "").replace("^", "").replace("!", "");
					String out = associateId2File.get(input) == null ? "No linked notes found with that id." : associateId2File.get(input).toString();
					System.out.println(input + ":" + out);
					System.out.println();
				}
				if(cmd == 7) {
					System.out.println("System Exiting, thank you for using the note taking system!");
				}
				//break;
			} // while
		} catch (Exception e) {
			System.out.println("Please check your input format and retry.");
		}
		System.out.println("System: Please restart the program for another query.");
	}
}
