package impl;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utils {
    // reads a file into a string
    public static String readFile(String path) throws IOException{
        Charset charset = Charset.forName("US-ASCII");
        return readFile(path, charset);
    }
    public static String readFile(String path, Charset encoding)
        throws IOException {
            byte[] encoded = Files.readAllBytes(Paths.get(path));
            return new String(encoded, encoding);
    }
	public static File[] listFiles(String folder){
		File directory = new File(folder);
		File[] contents = directory.listFiles();
		return contents;
	}
	public static ArrayList<String> matchPattern(Pattern pattern, String input) {
		ArrayList<String> rtn = new ArrayList<String>();
		Matcher matcher = pattern.matcher(input);
		while (matcher.find())
			rtn.add(matcher.group());
		return rtn;
	}
}
